import * as React from "react";
import {useFonts} from "expo-font";
import Inicio from "./presentation/views/auth/Inicio";
import Formulario from "./presentation/views/auth/Formulario";
import Login from "./presentation/views/auth/Login";
import {NavigationContainer} from "@react-navigation/native";
import {createNativeStackNavigator} from "@react-navigation/native-stack";

export type RootStackParamsList = {
  Login: undefined,
  Inicio: undefined,
  Formulario: undefined,
}
const Stack = createNativeStackNavigator<RootStackParamsList>();

export default function App() {
  const [fontsLoaded] = useFonts({
    "Roboto-Light": require("./assets/fonts/Roboto-Light.ttf"),
    "Roboto-Regular": require("./assets/fonts/Roboto-Regular.ttf"),
    "Roboto-Medium": require("./assets/fonts/Roboto-Medium.ttf"),
    "Roboto-Bold": require("./assets/fonts/Roboto-Bold.ttf"),
    "Roboto-Black": require("./assets/fonts/Roboto-Black.ttf"),
  });

    return (
        <NavigationContainer>

          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name={"Login"} component={Login} options={{headerShown: true, title: "Registro"}}></Stack.Screen>
            <Stack.Screen name={"Inicio"} component={Inicio} options={{title:"Navegación de administrador"}}></Stack.Screen>
            <Stack.Screen name={"Formulario"} component={Formulario} options={{title:"Navegación de administrador"}}></Stack.Screen>
          </Stack.Navigator>

        </NavigationContainer>
    );
  }


