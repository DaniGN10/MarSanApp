import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const Formulario = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.back}>Atrás ⬅</Text>

            <Text style={styles.title}>formulario</Text>
            <Text style={styles.subtitle}>MarSan</Text>

            <TextInput style={styles.input} placeholder="Nombre y Apellidos" />
            <TextInput style={styles.input} placeholder="Correo Electrónico" />

            <View style={styles.row}>
                <TextInput style={[styles.input, styles.halfInput]} placeholder="Número Telef" />
                <TextInput style={[styles.input, styles.halfInput]} placeholder="DNI / NIE" />
            </View>

            <TextInput style={styles.input} placeholder="Datos del domicilio" />

            <View style={styles.row}>
                <TextInput style={[styles.input, styles.halfInput]} placeholder="Localidad" />
                <TextInput style={[styles.input, styles.halfInput]} placeholder="CP" />
            </View>

            <TextInput style={styles.largeInput} placeholder="Descripción breve del Trabajo" multiline />
            <TextInput style={styles.largeInput} placeholder="Piezas Usadas" multiline />

            <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>Generar PDF</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#dbeafe',
        alignItems: 'center',
        padding: 20,
    },
    back: {
        alignSelf: 'flex-start',
        fontSize: 14,
        color: '#333',
        marginBottom: 10,
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#444',
        textTransform: 'lowercase',
    },
    subtitle: {
        fontSize: 14,
        color: '#666',
        marginBottom: 20,
    },
    input: {
        backgroundColor: '#fff',
        width: '100%',
        padding: 10,
        borderRadius: 5,
        marginBottom: 10,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
    },
    halfInput: {
        width: '48%',
    },
    largeInput: {
        backgroundColor: '#fff',
        width: '100%',
        padding: 10,
        borderRadius: 5,
        marginBottom: 10,
        height: 80,
        textAlignVertical: 'top',
    },
    button: {
        backgroundColor: '#1e40af',
        paddingVertical: 10,
        paddingHorizontal: 40,
        borderRadius: 5,
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
    },
});

export default Formulario;