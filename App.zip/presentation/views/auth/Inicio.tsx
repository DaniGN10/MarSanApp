import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const Inicio = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.logout}>Cerrar Sesión ➜</Text>

            <View style={styles.section}>
                <Text style={styles.title}>formulario</Text>
                <Text style={styles.subtitle}>MarSan</Text>
                <TouchableOpacity style={styles.button}>
                    <Text style={styles.buttonText}>Acceder</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.section}>
                <Text style={styles.title}>estado tareas</Text>
                <Text style={styles.subtitle}>MarSan</Text>
                <TouchableOpacity style={styles.button}>
                    <Text style={styles.buttonText}>Acceder</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#dbeafe',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logout: {
        position: 'absolute',
        top: 20,
        right: 20,
        fontSize: 14,
        color: '#333',
    },
    section: {
        alignItems: 'center',
        marginBottom: 40,
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#444',
        textTransform: 'lowercase',
    },
    subtitle: {
        fontSize: 14,
        color: '#666',
        marginBottom: 10,
    },
    button: {
        backgroundColor: '#1e40af',
        paddingVertical: 10,
        paddingHorizontal: 40,
        borderRadius: 5,
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
    },
});

export default Inicio;
