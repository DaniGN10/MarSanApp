

export const AppFonts = {
    medium: "Roboto-Medium",
}